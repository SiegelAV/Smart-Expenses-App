using Humanizer.Localisation.DateToOrdinalWords;
using Microsoft.AspNetCore.Mvc;
using MVC_Controller_App_Test.Models;
using Smart_Expenses_App.Models;
using System.Diagnostics;

namespace MVC_Controller_App_Test.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly ExpensesDBContext _context;

        public HomeController(ILogger<HomeController> logger, ExpensesDBContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Expenses() 
        {
            var allExpenses = _context.Expenses.ToList();

            var totalExpenses = allExpenses.Sum(x => x.Value);

            ViewBag.Expenses = totalExpenses;

            return View(allExpenses);
        }

        public IActionResult CreateEditExpense(int? id)
        {
            if (id != null)
            {  
                // editing -> load an expense by id
                var expenseInDb = _context.Expenses.SingleOrDefault(expense => expense.Id == id);

                return View(expenseInDb);
            }
 

            return View();
        }

        public IActionResult DeleteExpense(int id)
        {
            var expenseInDb = _context.Expenses.SingleOrDefault(expense => expense.Id == id);

            _context.Expenses.Remove(expenseInDb);

            _context.SaveChanges();

            return RedirectToAction("Expenses");
        }

        public IActionResult CreateEditExpenseForm(Expense model)
        {
            if(model.Id == 0)
            {
                //Create
                _context.Expenses.Add(model);
            } else
            {
                //Editing
                _context.Expenses.Update(model);
            }
            
            _context.SaveChanges();

            return RedirectToAction("Expenses");
        }

    /*    public IActionResult Privacy()
        {
            return View();
        }
    */

        public ActionResult Privacy()
        {
            var courses = new List<Course>
    {
        new Course { Id = 1, Name = "Budgeting 101", Description = "Learn the basics of budgeting and financial planning.", ImageUrl="/content/budgeting.jpg" },
        new Course { Id = 2, Name = "Investing for Beginners", Description = "Understand how to start investing to grow your wealth.", ImageUrl="/content/investing.jpg" },
        new Course { Id = 3, Name = "Debt Management", Description = "Explore effective methods to manage and reduce debt.", ImageUrl="/content/debt.jpg" },
        new Course { Id = 4, Name = "Retirement Planning", Description = "Plan for a secure and fulfilling retirement.", ImageUrl="/content/retirement.jpg" },
        new Course { Id = 5, Name = "Financial Independence", Description = "Achieve financial independence with step-by-step strategies.", ImageUrl="/content/financialindependence.jpg" },
        new Course { Id = 6, Name = "Tax Efficiency Strategies", Description = "Minimize your tax burden with smart strategies.", ImageUrl="/content/tax.jpg" },
        new Course { Id = 7, Name = "Saving for College", Description = "Plan ahead for your children's education costs.", ImageUrl="/content/college.jpg" }
    };

            return View(courses);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
