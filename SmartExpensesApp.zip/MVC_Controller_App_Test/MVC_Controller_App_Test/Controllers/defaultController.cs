﻿using Microsoft.AspNetCore.Mvc;

namespace MVC_Controller_App_Test.Controllers
{
    public class defaultController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
