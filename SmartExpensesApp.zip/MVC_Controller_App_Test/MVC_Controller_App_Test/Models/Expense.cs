﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Controller_App_Test.Models
{
    public class Expense
    {
        public int Id { get; set; }

        public decimal Value { get; set; }

        [Required]
        public string? Description { get; set; }
    }
}
