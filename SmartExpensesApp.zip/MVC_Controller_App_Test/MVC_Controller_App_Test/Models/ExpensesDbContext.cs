﻿using Microsoft.EntityFrameworkCore;

namespace MVC_Controller_App_Test.Models
{
    public class ExpensesDBContext : DbContext
    {
        public DbSet<Expense> Expenses { get; set; }

        public ExpensesDBContext(DbContextOptions<ExpensesDBContext> options)
            : base(options)
        {
                
        }
    }
}
