﻿namespace MVC_Controller_App_Test.Models
{
    public class userControllerClass
    {
        public int Number { get; set; }
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
